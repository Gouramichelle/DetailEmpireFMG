
import './setup.js';
import './contact.spec.jsx';
import './navbar.spec.jsx';
import './sanity.spec.jsx'