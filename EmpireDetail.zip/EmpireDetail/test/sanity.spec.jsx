describe('Sanity', () => {
  it('adapter cargado', () => {
    expect(true).toBeTrue();
  });
});
